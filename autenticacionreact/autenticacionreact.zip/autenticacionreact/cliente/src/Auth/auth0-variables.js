export const AUTH_CONFIG = {
  domain: 'juandevwp.auth0.com',
  clientId: 'yEP2exS3V6H3MJ36InuLXRjfrSE4mBcN',
  callbackUrl: 'http://localhost:3000/callback', 
  apiURL: 'http://productos'
}
