import React, { Component } from 'react';

class Nosotros extends Component {
     state = {}
     render() { 
          return ( <h1>Ruta no encontrada</h1> )
     }
}
 
export default Nosotros;